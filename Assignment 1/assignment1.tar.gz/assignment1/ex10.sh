#!/bin/bash

# Filename: ex10.sh
#
# Problem: Use a loop to count from 1 to 10


echo Count is: $count

