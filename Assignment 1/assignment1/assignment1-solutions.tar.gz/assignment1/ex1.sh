#!/bin/bash

# Filename: ex1.sh
#
# Problem: Make a script to print out "hello"

echo "hello"