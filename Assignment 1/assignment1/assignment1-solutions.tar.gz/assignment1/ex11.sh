#!/bin/bash

# Filename: ex11.sh
#
# Problem: Use quotes and escape meta characters to make the script work.


echo Jack had '$50' until he lost it betting at the races?

horse=Farlap
echo Jack\'s favourite horse was _$horse\_.

