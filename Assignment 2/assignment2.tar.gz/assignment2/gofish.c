#include <stdio.h>

int main(int args, char* argv[]) 
{
  fprintf(stdout, "Put your code here.");
}
